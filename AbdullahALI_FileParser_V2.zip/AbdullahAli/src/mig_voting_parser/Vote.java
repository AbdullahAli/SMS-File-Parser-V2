package mig_voting_parser;

/**
 * 
 * @author Abdullah
 * 
 * a class used to hold vote data
 */
public class Vote 
{
    /** the epoch of the vote - a unix time **/
    private String epoch;
    /** the name of the campaign **/
    private String campaign;
    /** the validity of the vote **/
    private String validity;
    /** the choice made by the vote **/
    private String choice;
    /** the conn of the vote **/
    private String conn;
    /** the msisdn of the vote **/
    private String msisdn;
    /** the guid of the vote **/
    private String guid;
    /** the shortcode of the vote **/
    private String shortcode;
    
    /**
     * Constructor of the vote - sets every field.
     */
    public Vote(String epoch, String campaign, String validity, String choice,
            String conn, String msisdn, String guid, String shortcode)
    {
        this.epoch = epoch;
        this.campaign = campaign;
        this.validity = validity;
        this.choice = choice;
        this.conn = conn;
        this.msisdn = msisdn;
        this.guid = guid;
        this.shortcode = shortcode;
    }
    
    /**
     * get the epoch value
     * @return - the epoch value
     */
    public String getEpoch()
    {
        return epoch;
    }
    
    /**
     * get the msisdn value
     * @param msisdn - the msisdn value
     */
    public void setMSISDN(String msisdn)
    {
        this.msisdn = msisdn;
    }
    
    /**
     * get the short code
     * @param shortcode - the shortcode value
     */
    public void setShortcode(String shortcode)
    {
        this.shortcode = shortcode;
    }
    
    /**
     * get the campaign
     * @return - the campaign
     */
    public String getCampaign()
    {
        return campaign;
    }
    
    /**
     * get the validity of the vote
     * @return - the validity of the vote
     */
    public String getValidity()
    {
        return validity;
    }
    
    /**
     * get the choice made
     * @return - the choice made
     */
    public String getChoice()
    {
        return choice;
    }
    
    /**
     * get the conn of the vote
     * @return - the conn of the vote
     */
    public String getConn()
    {
        return conn;
    }
    
    /**
     * get the msisdn of the vote
     * @return - the msisdn of the vote
     */
    public String getMSISDN()
    {
        return msisdn;
    }
    
    /**
     * get the guid of the vote
     * @return - the guid
     */
    public String getGuid()
    {
        return guid;
    }
    
    /** 
     * get the shortcode of the vote
     * @return - the shortcode of the vote
     */
    public String getShortcode()
    {
        return shortcode;
    }
}
