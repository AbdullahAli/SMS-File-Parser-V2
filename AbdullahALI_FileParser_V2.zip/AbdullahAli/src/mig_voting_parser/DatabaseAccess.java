package mig_voting_parser;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * 
 * @author Abdullah
 * 
 * This class is used as the only layer to access the database.
 * This class contains the insertVotesToDatabase method , which inserts votes into the database.
 * If database used changes in future; this is the only class that needs to be modified.
 * Note note: this layer makes use of a temporary file used for parsing the votes - to enhance
 * the speed of "dumping" data into the database.
 */
public class DatabaseAccess 
{ 
   /** A basic counter used to counter the number of objects inserted into the database**/
    private int numberOfRowsInserted;
    
    /**
     * This method is used to inserted votes into the database.
     * @param votes - the votes collection to be inserted into the database.
     */
    public void insertVotesToDatabase(ArrayList<Vote> votes)
    {
        Connection connection = null;
        Statement statement = null;
        try
        {
            //make a connection 
            //database: MIG_VOTES
            //username: david
            //password: password
            
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MIG_VOTES?user=david&password=password");
            statement = connection.createStatement();
            
            //use local data infile to speed up the data insertion time into the database.
            String insertString = " LOAD DATA LOCAL INFILE 'tempMigVotesFile.txt' INTO TABLE tblVotes"
                    + " FIELDS TERMINATED BY \'\\t\' LINES TERMINATED BY \'\\n\'";

            numberOfRowsInserted = statement.executeUpdate(insertString);
            
            //house keeping - remove the temporary file.
            File file = new File("tempMigVotesFile.txt");
            file.delete();
        } 
        catch (SQLException ex) 
        {
            //Give user error message with regards to database.
            JOptionPane.showMessageDialog(null, "Cant connect to database.\n"+ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
        } 
        finally
        {
            //house keeping.
            if(connection != null)
            {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DatabaseAccess.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
            //house keeping.
            if(statement != null)
            {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DatabaseAccess.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    /**
     * Used to return the number of rows inserted into the database.
     * @return - the number of rows inserted.
     */
    public int getNumberOfRowsInserted()
    {
        return numberOfRowsInserted;
    }
}
