<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>     
  <head>       
    <meta http-equiv="content-type" content="text/html; charset=windows-1250">       
    <meta name="generator" content="PSPad editor, www.pspad.com">       
    <title>MIG Votes</title>       
    <link rel="stylesheet" type="text/css" href="style.css" />     
  </head>     
  <body>
<?php
    
    //start the application  
    displayCampaigns(); 
    displayChoiceResults();
    
    /**
     *used to make a connection
     */         
    function makeConnection()
    {
      $connection = mysql_connect("localhost","david","password") or die ("Could not connect to database") or die ("Error: ".mysql_error());
      mysql_select_db("MIG_VOTES", $connection) or die ("Error: ".mysql_error());
      return $connection;
    }
    
    /**
     *used to close the connection
     */         
    function closeConnection($connection)
    {
      mysql_close($connection) or die ("Error: ".mysql_error());;
    }
    
    /**
     *displsys the campaigns
     */         
    function displayCampaigns()
    {
      $connection = makeConnection();
      //get all the campaigns
      $campaignResults = mysql_query("SELECT DISTINCT campaign FROM tblVotes") or die ("Error: ".mysql_error());
      
      //make a drop down form that refreshes the page on selection
      $dropdownform = "<form action='votes.php' method='post' name='test' class='dropdownform'> ";
      $dropdownform .= "<table><tr><td>Campaign</td></tr><tr><td>";
      $dropdownform .= "<select name='campaign' onchange='this.form.submit();'> ";
      
      //add the campaigns to the drop down list
      while($row = mysql_fetch_assoc($campaignResults))
      {
        $dropdownform .= "<option value='".$row['campaign']."'>".$row['campaign']."</option> ";
      }
      closeConnection($connection);
      $dropdownform .= "</select></td></table></form>"; 
      echo $dropdownform;
    }
    
    /**
     *displays the choices for the chosen campaign
     */         
    function displayChoiceResults()
    {
      if(isset($_POST['campaign']))
      {
        $connection = makeConnection();
        
        //get all choices for campaign
        $campaign = $_POST['campaign'];
        $choice_sql = "SELECT DISTINCT choice FROM tblVotes WHERE campaign = '$campaign'";
        $choiceResults = mysql_query($choice_sql) or die ("Error: ".mysql_error());
        
        //Table headers
        echo "<div class='choiceTable'><table>";
        echo "<tr class='d0'>";
        echo "<td><b>You have selected: ".$campaign."</b></td>";
        echo "<td>Choice</td>";
        echo "<td>Scores</td>";
        echo "<td>Uncounted Messages</td>";
        echo "</tr>";
        
        //Overall total counters
        $totalValid = 0;
        $totalInvalid =0;
        
        //while there is more choices found
        while($row = mysql_fetch_array($choiceResults))
        {
          $choice = $row[0];
          
          //set the valid, invalid and total counts 
          $validChoiceCountResult = mysql_query("SELECT count(choice) as total FROM tblvotes WHERE choice = '$choice' AND campaign = '$campaign' AND validity = 'during'") or die ("Error: ".mysql_error());
    		  $validVotesForChoice = mysql_fetch_assoc($validChoiceCountResult);
          $totalValid = $totalValid + $validVotesForChoice['total'];
          $invalidChoiceCountResult = mysql_query("SELECT count(choice) as total FROM tblvotes WHERE choice = '$choice' AND campaign = '$campaign' AND validity != 'during'") or die ("Error: ".mysql_error());
    		  $invalidVotesForChoice = mysql_fetch_assoc($invalidChoiceCountResult);
          $totalInvalid = $totalInvalid + $invalidVotesForChoice['total'];
          
          //echo the choices and their results
          echo "<tr><td></td>";
       	  echo "<td>".$choice."</td>";
          echo "<td>".$validVotesForChoice['total']."</td>"; 
        	echo "<td>".$invalidVotesForChoice['total']."</td>"; 
        }
        //echo total and close table
        echo "<tr class='d0'><td></td>";
        echo "<td>TOTAL</td>";
        echo "<td>".$totalValid."</td>"; 
        echo "<td>".$totalInvalid."</td>"; 
        echo "</table></div>";
        closeConnection($connection);
      }
    }
?>       
  </body>
</html>